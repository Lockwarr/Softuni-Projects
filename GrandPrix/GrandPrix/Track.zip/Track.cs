﻿using System;
using System.Collections.Generic;
using System.Text;

public class Track
{
    private int lapsNumber;
    private int trackLength;
    private Weather weather;

    public Track(int lapsNumber, int trackLength)
    {
        this.lapsNumber = lapsNumber;
        this.trackLength = trackLength;
        this.weather = Weather.Sunny;
    }
}
