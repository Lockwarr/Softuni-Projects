﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Moods

{

    public abstract class Mood

    {

        private int happinessPoints;



        public Mood(int happinessPoints)

        {

            this.happinessPoints = happinessPoints;

        }

    }

}