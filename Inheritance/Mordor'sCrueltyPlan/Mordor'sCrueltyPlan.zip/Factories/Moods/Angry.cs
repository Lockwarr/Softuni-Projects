﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Moods

{

    public class Angry : Mood

    {

        public Angry(int happinessPoints) : base(happinessPoints)

        {

        }

    }
}