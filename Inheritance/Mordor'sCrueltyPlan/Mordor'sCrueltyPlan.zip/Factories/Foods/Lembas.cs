﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Foods

{

    public class Lembas : Food

    {

        private const int PointsOfHappiness = 3;



        public Lembas() : base(PointsOfHappiness)

        {

        }

    }

}