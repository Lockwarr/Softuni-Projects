﻿using System;


class Program
{
    static void Main(string[] args)
    {
        double length = double.Parse(Console.ReadLine());
        double width = double.Parse(Console.ReadLine());
        double height = double.Parse(Console.ReadLine());
        if (length <= 0)
        {
            Console.WriteLine("Length cannot be zero or negative.");
        }
        else if (width <= 0)
        {
            Console.WriteLine("Width cannot be zero or negative.");
        }
        else if (height <= 0)
        {
            Console.WriteLine("Height cannot be zero or negative.");
        }
        else
        {
            Box box = new Box();
            box.GetSA(length, width, height);
            box.GetLSA(length, width, height);
            box.GetVolume(length, width, height);
            Console.WriteLine(box.ToString());
        }
    }

}
