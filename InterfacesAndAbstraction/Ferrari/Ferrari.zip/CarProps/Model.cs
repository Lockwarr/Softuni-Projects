﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ferrari.CarProps
{
    public class Model
    {
        public string model = "488-Spider";
    }
}
