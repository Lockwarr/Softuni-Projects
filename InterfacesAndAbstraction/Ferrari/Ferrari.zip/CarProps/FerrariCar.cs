﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ferrari.CarProps
{
    public class FerrariCar : Car
    {
        public string PushGas()
        {
            return "Zadu6avam sA!";
        }

        public string UseBrakes()
        {
            return "Brakes!";
        }
    }
}
