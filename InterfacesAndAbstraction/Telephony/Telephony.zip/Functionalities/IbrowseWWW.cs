﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Functionalities
{
    public interface IbrowseWWW
    {
        string Browse(string url);
    }
}
