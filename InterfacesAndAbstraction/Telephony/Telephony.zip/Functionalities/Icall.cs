﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Functionalities
{
    public interface Icall
    {
        string Call (string number);
    }
}
