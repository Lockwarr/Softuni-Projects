﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IDetailsFormat
{
    string Name { get; }
    string ID { get;  }
}

