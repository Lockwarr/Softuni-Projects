﻿using System;
using System.Collections.Generic;
using System.Text;


class Person
{
    public string name;
    public int age;
    public Person(string name, int age)
    {
        this.name = name;
        this.age = age;
    }
}


