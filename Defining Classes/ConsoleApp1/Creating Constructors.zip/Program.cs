﻿using System;


class Program
{
    static void Main(string[] args)
    {
        var Person1 = new Person();
        var Person2 = new Person(32);
        var Person3 = new Person("Gary" , 45);

    }
}

