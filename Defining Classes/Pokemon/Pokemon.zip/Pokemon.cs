﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;



namespace _08.Pokemon_Trainer

{

    public class Pokemon

    {

        public string name;

        public string element;

        public int health;



        public Pokemon(string name, string element, int health)

        {

            this.name = name;

            this.element = element;

            this.health = health;

        }

    }

}